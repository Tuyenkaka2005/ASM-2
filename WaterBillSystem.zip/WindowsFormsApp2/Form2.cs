﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtUserName.Clear();
            txtPassword.Clear();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string userName = txtUserName.Text;
            string password = txtPassword.Text;
            if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("User name and password cannot be empty.");
                return;
            }
            for (int i = 0; i < Form1.userCount; i++)
            {
                if (Form1.userNames[i] == userName)
                {
                    MessageBox.Show("User already exists. Please choose a different user name.");
                    return;
                }
            }
            if (Form1.userCount < Form1.userNames.Length)
            {
                Form1.userNames[Form1.userCount] = userName;
                Form1.passwords[Form1.userCount] = password;
                Form1.userCount++;
                MessageBox.Show("Registration successful!","",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                this.Close();
                Form1 form1 = new Form1();
                form1.Show();
            }
            else
            {
                MessageBox.Show("User limit reached. Cannot register more users.");
            }
        } 
    }
}
