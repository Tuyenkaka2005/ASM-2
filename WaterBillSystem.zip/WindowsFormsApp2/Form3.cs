﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{

    public partial class Form3 : Form
    {
        const int Max_Customers = 100;
        static string[] customerNames = new string[Max_Customers];
        static int[] lastMonthReadings = new int[Max_Customers];
        static int[] thisMonthReadings = new int[Max_Customers];
        static string[] customerTypes = new string[Max_Customers];
        static int[] numberOfPeople = new int[Max_Customers];
        static int[] consumptions = new int[Max_Customers];
        static double[] vats = new double[Max_Customers];
        static double[] totalWaterBills = new double[Max_Customers];
        static int[] PerCapitaConsumption = new int[Max_Customers];
        static double[] WaterBill = new double[Max_Customers];
        static double[] eFee = new double[Max_Customers];
        static string[] phoneNumbers = new string[Max_Customers];
        int customerCount = 0;


        public Form3()
        {
            InitializeComponent();
            cbCustomerType.Items.Add("Household");
            cbCustomerType.Items.Add("Administrative agency, Public services");
            cbCustomerType.Items.Add("Production units");
            cbCustomerType.Items.Add("Business services");
            cbCustomerType.SelectedIndexChanged += cbCustomerType_SelectedIndexChanged;

            InitializeDataGridView();
        }
        private void InitializeDataGridView()
        {
            dataGridViewCustomers.ColumnCount = 4;
            dataGridViewCustomers.Columns[0].Name = "Name";
            dataGridViewCustomers.Columns[1].Name = "Phone";
            dataGridViewCustomers.Columns[2].Name = "Customer Type";
            dataGridViewCustomers.Columns[3].Name = "Total";
        }
        private int GetCustomer(int customerCount)
        {
            customerNames[customerCount] = txtCustomerName.Text;
            lastMonthReadings[customerCount] = int.Parse(txtLastMonth.Text);
            thisMonthReadings[customerCount] = int.Parse(txtThisMonth.Text);
            phoneNumbers[customerCount] = txtPhone.Text;

            if (thisMonthReadings[customerCount] < lastMonthReadings[customerCount])
            {
                MessageBox.Show("This month's water meter readings cannot be lower than last month's.");
                this.Hide();
                new Form3().ShowDialog();
                return customerCount;  
            }

            customerTypes[customerCount] = cbCustomerType.SelectedItem.ToString();

            if (customerTypes[customerCount].ToLower() == "household")
            {
                numberOfPeople[customerCount] = (int)numNumberOfPeople.Value;
            }
            else
            {
                numberOfPeople[customerCount] = 1;
            }

            consumptions[customerCount] = thisMonthReadings[customerCount] - lastMonthReadings[customerCount];
            PerCapitaConsumption[customerCount] = consumptions[customerCount] / numberOfPeople[customerCount];

            CalculateBill(customerCount);

            return customerCount + 1;
        }
        private void CalculateBill(int customerCount)
        {
            double pricePerM3 = GetPricePerM3(customerCount);
            double waterbill = pricePerM3 * PerCapitaConsumption[customerCount];


            WaterBill[customerCount] = waterbill;


            eFee[customerCount] = waterbill * 0.1;
            vats[customerCount] = waterbill * 0.1;
            totalWaterBills[customerCount] = waterbill + vats[customerCount] + eFee[customerCount];
        }
        private double GetPricePerM3(int customerCount)
        {
            double pricePerM3 = 0;

            switch (customerTypes[customerCount].ToLower())
            {
                case "household":
                    if (PerCapitaConsumption[customerCount] <= 10 * numberOfPeople[customerCount])
                    {
                        pricePerM3 = 5.973;
                    }
                    else if (PerCapitaConsumption[customerCount] <= 20 * numberOfPeople[customerCount])
                    {
                        pricePerM3 = 7.052;
                    }
                    else if (PerCapitaConsumption[customerCount] <= 30 * numberOfPeople[customerCount])
                    {
                        pricePerM3 = 8.699;
                    }
                    else
                    {
                        pricePerM3 = 15.929;
                    }
                    break;
                case "administrative agency, public services":
                    pricePerM3 = 9.955;
                    break;
                case "production units":
                    pricePerM3 = 11.615;
                    break;
                case "business services":
                    pricePerM3 = 22.068;
                    break;
            }

            return pricePerM3;
        }
        private void DisplayCustomer(int customerIndex)
        {
            txtResult.Text = $"Customer Name: {customerNames[customerIndex]}\r\n" +
                             $"Phone: {txtPhone.Text}\r\n" +              
                             $"Customer Type: {customerTypes[customerIndex]}\r\n" +
                             $"Amount of Consumption: {PerCapitaConsumption[customerIndex]} m³\r\n" +
                             $"Water Bills: {WaterBill[customerIndex]} VND\r\n" +
                             $"Environment Protection Fee (10%): {eFee[customerIndex]} VND \r\n" +
                             $"VAT (10%): {vats[customerIndex]:N2} VND\r\n" +
                             $"Total Water Bill : {totalWaterBills[customerIndex]:N2} VND";

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtCustomerName.Clear();
            txtLastMonth.Clear();
            txtThisMonth.Clear();
            txtPhone.Clear();
            cbCustomerType.Items.Remove(cbCustomerType.SelectedIndex);
            numNumberOfPeople.Value = 0;
            txtResult.Clear();

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCustomerName.Text) ||
                string.IsNullOrEmpty(txtPhone.Text) ||
                cbCustomerType.SelectedItem == null)
                return;

            if (customerCount < Max_Customers)
            {
                customerCount = GetCustomer(customerCount);
                DisplayCustomer(customerCount - 1);
            }
            else
            {
                MessageBox.Show("Maximum customer limit reached.");
            }
            
            double totalBill = totalWaterBills[customerCount - 1];
            ListViewItem item = new ListViewItem((listView.Items.Count+1).ToString());

            item.SubItems.Add(txtCustomerName.Text);
            item.SubItems.Add(txtPhone.Text);
            item.SubItems.Add(cbCustomerType.SelectedItem.ToString());
            item.SubItems.Add(totalBill.ToString("N2"));

            listView.Items.Add(item);
            txtCustomerName.Clear();
            txtPhone.Clear();
            txtCustomerName.Focus();

            
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (listView.Items.Count > 0)
                listView.Items.Remove(listView.SelectedItems[0]);
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Do you want to exit",
                "Warning", MessageBoxButtons.YesNoCancel,
                MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void numNumberOfPeople_ValueChanged(object sender, EventArgs e)
        {

        }

        private void cbCustomerType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbCustomerType.SelectedItem != null 
                && cbCustomerType.SelectedItem.ToString().ToLower() 
                == "household")
            {
                numNumberOfPeople.Show();
            }
            else
            {
                numNumberOfPeople.Hide();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string phoneNumber = txtSearchPhone.Text;
            var matchingIndexes = GetRecordsByPhoneNumber(phoneNumber);
            DisplaySearchResults(matchingIndexes);
        }
        private List<int> GetRecordsByPhoneNumber(string phoneNumber)
        {
            List<int> matchingIndexes = new List<int>();
            for (int i = 0; i < customerCount; i++)
            {
                if (phoneNumbers[i] == phoneNumber)
                {
                    matchingIndexes.Add(i);
                }                
            }
            return matchingIndexes;
        }
        private void DisplaySearchResults(List<int> searchResults)
        {
            dataGridViewCustomers.Rows.Clear();
            foreach (var index in searchResults)
            {
                dataGridViewCustomers.Rows.Add(customerNames[index], 
                    phoneNumbers[index], customerTypes[index], 
                    totalWaterBills[index].ToString("N2"));
            }
        }

        private void listView_ColumnClick(object sender, ColumnClickEventArgs e)
        {

        }

        private void btnDescending_Click(object sender, EventArgs e)
        {
            SortSmallestToLargest();
        }

        private void btnAscending_Click(object sender, EventArgs e)
        {
            SortLargestToSmallest();
        }
        private void SortSmallestToLargest()
        {
            listView.ListViewItemSorter = new ListViewItemComparer(0, true);
            listView.Sort();
        }

        private void SortLargestToSmallest()
        {
            listView.ListViewItemSorter = new ListViewItemComparer(0, false);
            listView.Sort();
        }

        private class ListViewItemComparer : IComparer
        {
            private int col;
            private bool ascending;

            public ListViewItemComparer(int column, bool ascending)
            {
                col = column;
                this.ascending = ascending;
            }

            public int Compare(object x, object y)
            {
                int returnVal = -1;
                returnVal = int.Parse(((ListViewItem)x).SubItems[col].Text).CompareTo                   
                            (int.Parse(((ListViewItem)y).SubItems[col].Text));
                
                if (!ascending)
                    returnVal *= -1;

                return returnVal;
            }
        }
    }
}
