﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public static string[] userNames = new string[10];
        public static string[] passwords = new string[10];
        public static int userCount = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtUserName.Clear();
            txtPassword.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string userName = txtUserName.Text;
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("User name and password cannot be empty.","Warning",
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Error);
                return;
            }
            bool loginSuccess = false;
            for (int i = 0; i < userCount; i++)
            {
                if (userNames[i] == userName && passwords[i] == password)
                {
                    loginSuccess = true;
                    break;
                }
            }
            if (loginSuccess)
            {
                MessageBox.Show("Login successful!","",
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Information);

                Form3 form3 = new Form3();
                form3.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show(
                    "Invalid user name or password.",
                    "Warning",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
